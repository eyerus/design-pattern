package com.company;
import jdk.nashorn.internal.runtime.ECMAException;

import java.util.Scanner;

public class banking {

    static double balance = 400;
    static double amount = 0;

    public static void main(String[] args) {
        // TODO code application logic here
        display();
        System.out.println("To continue enter 1 and to exit enter -1");
        Scanner input = new Scanner(System.in);
        int conti = input.nextInt();
        while(conti == 1){
            display();
        }
        try{
            System.out.println("Your balance is " +balance);
        }catch (Exception e){
            System.out.println("error");
        }finally {
            System.out.println("THank you for using our company");
        }
    }
    public static void display(){
        System.out.println("**************Welcome to Commercial Bank of Ethiopia.*******************************");
        System.out.println("--------------Choose the service you want-------------------------------------------");
        System.out.println("*************      1.checking your  current balance          ***********************");
        System.out.println("*************      2 for a deposit                           ***********************");
        System.out.println("*************      3 for a withdraw                          ***********************");
        Scanner input = new Scanner(System.in);
        int service = input.nextInt();

        if (service == 1){
            currentBalance();
        }
        else if (service == 2){
            deposit(amount);
        }
        else if(service == 3 && currentBalance()== 0){
            System.out.println("You need to deposit to be a customor of this bank\n");
            deposit(amount);
        }
        else{
            withdraw(amount);
        }
    }

    public static double currentBalance(){
        System.out.println("Your current balance is: "+ balance);
        return balance;
    }
    public static double withdraw(double amount){
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the amount you want to withdraw: ");
        amount = input.nextDouble();
        balance = balance - amount;
        System.out.println("The withdraw was successfull.Your currnt balance is: "+ balance);
        return balance;
    }
    public static double deposit(double amount){
        Scanner input = new Scanner(System.in);
        System.out.println("Enter the amount you want to deposit: ");
        amount = input.nextDouble();
        balance = balance + amount;
        System.out.println("The deposition was successfully completed.Your current balance is: "+ balance);
        return balance;
    }

}
