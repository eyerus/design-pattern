package com.company;

public interface interfaceHotel {
    public  int drinkMenu(int x);
    public  int foodMenu(int x);
    public int recreationMenu(int x);

}
