package com.company;

import java.util.Scanner;

public class Main {

    public void main(String[] args) {
        HaileResortandSpa res = new HaileResortandSpa();
        System.out.println("-----------------The code is for hotel menu------------------------");
        System.out.println("------welcome to our hotel we are ready to fullfill your wants----------");
        System.out.println("----here are our services and menus--------");
        System.out.println("*******1.food*******");
        System.out.println("*******2.drink******");
        System.out.println("*******3.recreation and spa*******");
        System.out.println("*******4.EXIT*******");
        System.out.println("enter your choice here using the numbers: ");
        Scanner input = new Scanner(System.in);
        int choice;
        choice = input.nextInt();
        if (choice == 1){
            res.foodMenu(1);
        }
        else if (choice == 2){
            res.drinkMenu(1);
        }
        else if (choice == 3){
            res.recreationMenu(1);
        }
        else if(choice == 4){
            System.out.println("thanks for visiting");
        }
        else{
            System.out.println("there is no service on what you choose");
        }
    }}

