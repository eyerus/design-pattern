package arrayInterface;

public interface Restuarants {
    public void drinks();
    public void food();
    public void Wifi();
}
