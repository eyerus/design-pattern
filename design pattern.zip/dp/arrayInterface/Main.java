package arrayInterface;
import java.util.ArrayList;
import java.util.Arrays;

public class Main {

    public static void main(String[] args) {


        aratkiloRestuarants romina = new aratkiloRestuarants();
        piassaRestuarants inandout = new piassaRestuarants();

        String restaurantOne = romina.setName("Romina cafe and Restuarant");
        String restaurantTwo = inandout.setName("InAndOut Burger");

        String[] myChoice = new String[2];
        myChoice[0]= restaurantOne;
        myChoice[1]= restaurantTwo;

        System.out.println("my favorite restuarants in addis are " );

        for(int i=0;i < myChoice.length;i++){
            System.out.println(myChoice[i]);
        }

    }
}

class aratkiloRestuarants implements Restuarants {
    public static void main(String[] args) {
        String nameOfRestuarants;


    }

    String setName(String name){
        return name;
    }

    @Override
    public void drinks() {
        System.out.println("All the resturants in aratkilo have water,softdrinks and hotdrinks");

    }

    @Override
    public void food() {
        System.out.println("All the resturants in aratkilo have firfir,shiro and tibs");
    }
    public void Wifi() {
        System.out.println("All the resturants in aratkilo have wifi access");
    }
}
class piassaRestuarants implements Restuarants {
    public static void main(String[] args) {
        String nameOfRestuarants;


    }
        String setName(String name){
        return name;
    }

    @Override
    public void drinks() {

        System.out.println("All the resturants in aratkilo have water,softdrinks and hotdrinks");
    }

    @Override
    public void food() {
        System.out.println("All the resturants in aratkilo have firfir,shiro and tibs");

    }
    public void Wifi() {
        System.out.println("All the resturants in aratkilo have wifi access");

    }
}
