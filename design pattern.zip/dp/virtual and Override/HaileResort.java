package com.company;


import java.util.Scanner;
public class HaileResort {
     public int foodMenu(int x){
        System.out.println("you have choosen food sevices");
        System.out.println("here is the menu for food");
        System.out.println("-----1.piazza----");
        System.out.println("-----2.fish----");
        System.out.println("-----3.dorowot----");
        System.out.println("enter your choice using the numbers;  ");
        int choice1;
        Scanner input = new Scanner(System.in);
        choice1 = input.nextInt();
        if (choice1 == 1){
            System.out.println("you have choosen piazza and the cost is 120birr");

        }
        else if (choice1 == 2){
            System.out.println("you have choosen fish and the cost is 70birr");
        }
        else if (choice1 == 3){
            System.out.println("you have choosen dorowot and the cost is 80birr");
        }
        else{
            System.out.println("Sorry....The food is not in our service menu");
        }
        return choice1;
    }
    public  int drinkMenu(int x){
        System.out.println("you have choosen drink sevices");

        System.out.println("here is the menu for drink");
        System.out.println("-----1.soft drink----");
        System.out.println("-----2.beer----");
        System.out.println("-----3.tea----");
        System.out.println("enter your choice using the numbers;  ");
        int choice2;
        Scanner input = new Scanner(System.in);
        choice2 = input.nextInt();
        if (choice2 == 1){
            System.out.println("you have choosen softdrink and the cost is 10birr");
        }
        else if (choice2 == 2){
            System.out.println("you have choosen beer and the cost is 15birr");
        }
        else if (choice2 == 3){
            System.out.println("you have choosen tea and the cost is 7birr");
        }
        else{
            System.out.println("Sorry....The drink is not in our service menu");
        }
        return choice2;
    }
    public int recreationMenu(int x){
        System.out.println("you have choosen recreation sevices");
        System.out.println("here is the menu for recreation");
        System.out.println("-----1.swimming----");
        System.out.println("-----2.gym----");
        System.out.println("-----3.spa----");
        System.out.println("enter your choice using the numbers;  ");
        int choice3;
        Scanner input = new Scanner(System.in);
        choice3 = input.nextInt();
        if (choice3 == 1){
            System.out.println("you have choosen swimming and the cost is 120birr");
        }
        else if (choice3 == 2){
            System.out.println("you have choosen gym and the cost is 70birrv for an hour");
        }
        else if (choice3 == 3){
            System.out.println("you have choosen spa and the cost is 180birr");
        }
        else{
            System.out.println("Sorry....The you choice is not in our service menu");
        }
        return choice3;
    }


}
class HaileResortandSpa extends HaileResort {
        public  int foodMenu(int x){
        System.out.println("you have choosen food sevices");
        System.out.println("here is the menu for food");
        System.out.println("-----1.piazza----");
        System.out.println("-----2.fish----");
        System.out.println("-----3.dorowot----");
        System.out.println("-----4.tibs----");
        System.out.println("enter your choice using the numbers;  ");
        int choice1;
        Scanner input = new Scanner(System.in);
        choice1 = input.nextInt();
        if (choice1 == 1){
            System.out.println("you have choosen piazza and the cost is 120birr");

        }
        else if (choice1 == 2){
            System.out.println("you have choosen fish and the cost is 70birr");
        }
        else if (choice1 == 3){
            System.out.println("you have choosen dorowot and the cost is 80birr");
        }else if (choice1 == 4){
            System.out.println("you have choosen tibs and the cost is 65birr");
        }
        else{
            System.out.println("Sorry....The food is not in our service menu");
        }
        return choice1;
    }
    public int drinkMenu(int x){
        System.out.println("you have choosen drink sevices");

        System.out.println("here is the menu for drink");
        System.out.println("-----1.soft drink----");
        System.out.println("-----2.beer----");
        System.out.println("-----3.tea----");
        System.out.println("-----4.coffee----");
        System.out.println("enter your choice using the numbers;  ");
        int choice2;
        Scanner input = new Scanner(System.in);
        choice2 = input.nextInt();
        if (choice2 == 1){
            System.out.println("you have choosen softdrink and the cost is 10birr");
        }
        else if (choice2 == 2){
            System.out.println("you have choosen beer and the cost is 15birr");
        }
        else if (choice2 == 3){
            System.out.println("you have choosen tea and the cost is 7birr");
        } else if (choice2 == 4){
            System.out.println("you have choosen coffee and the cost is 10birr");
        }
        else{
            System.out.println("Sorry....The drink is not in our service menu");
        }
        return choice2;
    }
    public int recreationMenu(int x){
        System.out.println("you have choosen recreation sevices");
        System.out.println("here is the menu for recreation");
        System.out.println("-----1.swimming----");
        System.out.println("-----2.gym----");
        System.out.println("-----3.spa----");
        System.out.println("-----4.horse riding----");
        System.out.println("enter your choice using the numbers;  ");
        int choice3;
        Scanner input = new Scanner(System.in);
        choice3 = input.nextInt();
        if (choice3 == 1){
            System.out.println("you have choosen swimming and the cost is 120birr");
        }
        else if (choice3 == 2){
            System.out.println("you have choosen gym and the cost is 70birrv for an hour");
        }
        else if (choice3 == 3){
            System.out.println("you have choosen spa and the cost is 180birr");
        }
        else if (choice3 == 4){
            System.out.println("you have choosen horse riding and the cost is 200birr");
        }
        else{
            System.out.println("Sorry....The you choice is not in our service menu");
        }
        return choice3;
    }
}


