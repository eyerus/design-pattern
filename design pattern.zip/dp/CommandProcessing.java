import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
 
 
public class CommandProcessing {
        public static void main(String[] args) {
		try {
			
			readFileAndPrintCounts(args[0]);
			
		} catch (FileNotFoundException e) {
                        
			e.printStackTrace();
		}
	}
 
	public static void readFileAndPrintCounts(String file) throws FileNotFoundException {
 
		int TotalWords = 0;
		int TotalLines = 0;
		int TotalCharacters = 0;
 
		String Line1;
 
		
		try (BufferedReader buffer = new BufferedReader(new FileReader(file))) {
			Log("========== File Content ==========");
 
			// read each line one by one
			while ((Line1 = buffer.readLine()) != null) {
				Log(Line1);
				TotalLines++;
 
				// ignore multiple white spaces
				String[] myWords = Line1.replaceAll("\\s+", " ").split(" ");
 
				for (String s : myWords) {
					TotalCharacters += s.length();
				}
 
				TotalWords += myWords.length;
 
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		Log("\n========== Result ==========");
 
		Log("* Total Characters: " + TotalCharacters);
		Log("* Total Words: " + TotalWords);
		Log("* Toal Lines: " + TotalLines);
	}
 
	private static void Log(String string) {
		System.out.println(string);
	}
 
	
}
