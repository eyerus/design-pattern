package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	    System.out.println("which of the following shapes area you want to calculate?");
	    System.out.println("1.circle");
        System.out.println("2.rectangle");
        System.out.println("3.triangle");
        int shape;
        Scanner scanner = new Scanner(System.in);
        shape = scanner.nextInt();
        calculateArea areaCalculation = new calculateArea();
        if(shape == 1){
            System.out.println("Enter the radius");
            Scanner scanner1 = new Scanner(System.in);
            int radius = scanner1.nextInt();
            areaCalculation.area(radius);

        }else if (shape == 2){
            System.out.println("Enter the height");
            Scanner scanner1 = new Scanner(System.in);
            int height = scanner1.nextInt();
            System.out.println("Enter the width");
            Scanner scanner2 = new Scanner(System.in);
            int width = scanner2.nextInt();
            areaCalculation.area(height,width);
        }else if (shape == 3){
            System.out.println("Enter the height");
            Scanner scanner1 = new Scanner(System.in);
            int height = scanner1.nextInt();
            System.out.println("Enter the width");
            Scanner scanner2 = new Scanner(System.in);
            int width = scanner2.nextInt();
            System.out.println("Enter the length of the third line");
            Scanner scanner3 = new Scanner(System.in);
            int third = scanner3.nextInt();
            areaCalculation.area(height,width,third);
        }else{
			System.out.println("Wrong choice");
		}
    }
}
