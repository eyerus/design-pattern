package com.company;

public interface factory {
    void area(int a);
}
