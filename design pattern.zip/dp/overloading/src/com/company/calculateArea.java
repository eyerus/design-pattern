package com.company;

public class calculateArea implements factory {

    public void area(int a){
        int areaResult = a * a;
        System.out.println("the area is " +areaResult);

    }
   public void  area(int a,int b){
        int areaResult = a * b;
        System.out.println("the area is " +areaResult);

    }
    public void area(int a,int b,int c){
        double areaResult = (0.5) * a * b;
        System.out.println("the area is " +areaResult);

    }

}
